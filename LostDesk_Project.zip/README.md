# LostDesk Management System

This package is generated from the uploaded LostDesk HTML project/documentation.

## Included
- LostDesk_Demo.html — original uploaded web interface
- Database/LostDesk_Database.sql — SQL Server schema
- Models/DatabaseHelper.cs — ADO.NET database helper
- Models/Models.cs — LostItem, FoundItem and Message models
- Controllers/ItemController.cs — MVC controller logic shown in the source
- Web.config — connection string/configuration represented in the source
- Report/LostDesk_Project_Report.pdf — project report

## Important
The uploaded source is a single HTML demonstration/documentation page that contains an ASP.NET/C#/SQL architecture explorer. The package extracts the backend code displayed inside that page; it is not claimed to be a fully compiled Visual Studio solution. Some views/project files referenced by the explorer are not embedded as complete files in the uploaded HTML.

## Technology shown
ASP.NET MVC, C#, HTML, Tailwind CSS, Font Awesome, SQL Server and ADO.NET.
