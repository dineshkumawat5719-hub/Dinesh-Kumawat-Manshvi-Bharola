using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.Mvc;
using LostDesk.Models;

namespace LostDesk.Controllers
{
    public class ItemController : Controller
    {
        private DatabaseHelper db = new DatabaseHelper();

        // GET: /Item/ReportLost
        public ActionResult ReportLost() => View();

        // POST: /Item/ReportLost (File Save to /Images/ & ADO.NET Parameterized Insert)
        [HttpPost]
        public ActionResult ReportLost(LostItem model, HttpPostedFileBase uploadImage)
        {
            if (ModelState.IsValid)
            {
                string imagePath = "/Images/default.jpg";
                if (uploadImage != null && uploadImage.ContentLength > 0)
                {
                    string fileName = Path.GetFileNameWithoutExtension(uploadImage.FileName) + "_" + Guid.NewGuid().ToString().Substring(0, 5) + Path.GetExtension(uploadImage.FileName);
                    string savePath = Path.Combine(Server.MapPath("~/Images/"), fileName);
                    uploadImage.SaveAs(savePath);
                    imagePath = "/Images/" + fileName;
                }

                string query = @"INSERT INTO LostItems (Name, Phone, Email, ItemName, Category, Brand, Color, Description, Location, LostDate, ImagePath) 
                                VALUES (@Name, @Phone, @Email, @ItemName, @Category, @Brand, @Color, @Description, @Location, @LostDate, @ImagePath)";

                SqlParameter[] parameters = {
                    new SqlParameter("@Name", model.Name),
                    new SqlParameter("@Phone", model.Phone),
                    new SqlParameter("@Email", model.Email),
                    new SqlParameter("@ItemName", model.ItemName),
                    new SqlParameter("@Category", model.Category),
                    new SqlParameter("@Brand", (object)model.Brand ?? DBNull.Value),
                    new SqlParameter("@Color", (object)model.Color ?? DBNull.Value),
                    new SqlParameter("@Description", model.Description),
                    new SqlParameter("@Location", model.Location),
                    new SqlParameter("@LostDate", model.LostDate),
                    new SqlParameter("@ImagePath", imagePath)
                };

                db.ExecuteNonQuery(query, parameters);
                return RedirectToAction("LostItems");
            }
            return View(model);
        }

        // GET: /Item/Search
        public ActionResult Search(string keyword, string category, string location)
        {
            string query = "SELECT * FROM LostItems WHERE 1=1";
            var paramsList = new System.Collections.Generic.List();

            if (!string.IsNullOrEmpty(keyword))
            {
                query += " AND (ItemName LIKE @Keyword OR Description LIKE @Keyword)";
                paramsList.Add(new SqlParameter("@Keyword", "%" + keyword + "%"));
            }
            if (!string.IsNullOrEmpty(category) && category != "ALL")
            {
                query += " AND Category = @Category";
                paramsList.Add(new SqlParameter("@Category", category));
            }
            if (!string.IsNullOrEmpty(location))
            {
                query += " AND Location LIKE @Location";
                paramsList.Add(new SqlParameter("@Location", "%" + location + "%"));
            }

            DataTable dt = db.ExecuteQuery(query, paramsList.ToArray());
            return View(dt);
        }
    }
}
