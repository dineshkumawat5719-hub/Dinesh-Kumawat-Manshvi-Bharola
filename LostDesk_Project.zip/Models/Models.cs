using System;

namespace LostDesk.Models
{
    public class LostItem
    {
        public int LostId { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string ItemName { get; set; }
        public string Category { get; set; }
        public string Brand { get; set; }
        public string Color { get; set; }
        public string Description { get; set; }
        public string Location { get; set; }
        public DateTime LostDate { get; set; }
        public string ImagePath { get; set; }
    }

    public class FoundItem
    {
        public int FoundId { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string ItemName { get; set; }
        public string Category { get; set; }
        public string Brand { get; set; }
        public string Color { get; set; }
        public string Description { get; set; }
        public string Location { get; set; }
        public DateTime FoundDate { get; set; }
        public string ImagePath { get; set; }
    }

    public class Message
    {
        public int MessageId { get; set; }
        public string SenderName { get; set; }
        public string SenderEmail { get; set; }
        public string Subject { get; set; }
        public string MessageContent { get; set; }
        public DateTime Date { get; set; }
    }
}
