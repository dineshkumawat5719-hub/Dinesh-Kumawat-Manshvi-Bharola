-- ============================================================
-- LostDesk SQL Server Database Table Schema Script
-- Engine: Microsoft SQL Server 2019 / 2022
-- ============================================================

CREATE DATABASE [LostDeskDB];
GO

USE [LostDeskDB];
GO

-- Table 1: LostItems
CREATE TABLE [dbo].[LostItems] (
    [LostId]      INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [Name]        NVARCHAR(100) NOT NULL,
    [Phone]       NVARCHAR(20)  NOT NULL,
    [Email]       NVARCHAR(100) NOT NULL,
    [ItemName]    NVARCHAR(150) NOT NULL,
    [Category]    NVARCHAR(50)  NOT NULL,
    [Brand]       NVARCHAR(50)  NULL,
    [Color]       NVARCHAR(30)  NULL,
    [Description] NVARCHAR(MAX) NOT NULL,
    [Location]    NVARCHAR(200) NOT NULL,
    [LostDate]    DATETIME      NOT NULL DEFAULT GETDATE(),
    [ImagePath]   NVARCHAR(255) NULL
);
GO

-- Table 2: FoundItems
CREATE TABLE [dbo].[FoundItems] (
    [FoundId]     INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [Name]        NVARCHAR(100) NOT NULL,
    [Phone]       NVARCHAR(20)  NOT NULL,
    [Email]       NVARCHAR(100) NOT NULL,
    [ItemName]    NVARCHAR(150) NOT NULL,
    [Category]    NVARCHAR(50)  NOT NULL,
    [Brand]       NVARCHAR(50)  NULL,
    [Color]       NVARCHAR(30)  NULL,
    [Description] NVARCHAR(MAX) NOT NULL,
    [Location]    NVARCHAR(200) NOT NULL,
    [FoundDate]   DATETIME      NOT NULL DEFAULT GETDATE(),
    [ImagePath]   NVARCHAR(255) NULL
);
GO

-- Table 3: Messages
CREATE TABLE [dbo].[Messages] (
    [MessageId]   INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [SenderName]  NVARCHAR(100) NOT NULL,
    [SenderEmail] NVARCHAR(100) NOT NULL,
    [Subject]     NVARCHAR(200) NOT NULL,
    [Message]     NVARCHAR(MAX) NOT NULL,
    [Date]        DATETIME      NOT NULL DEFAULT GETDATE()
);
GO
